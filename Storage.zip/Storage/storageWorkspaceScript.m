clear
clc

%% Key Inputs
base_year=2008;
start_year = 2022;
Lease_bonus = 50; % $/acre
dens_wells_CA = 0.25; %Density of deep wells needing Corrective action in wells/mi2

num_sites_char = 4; %Number of sites for characterization. (1 strat well & 2-D seis.)
num_2D_seismic_lines = 2; %Number of 2-D seismic lines for Site Selection & Site Characterization
num_strat_test_wells_succ_site = 2; %No. of Strat Test Wells on Successful Site,wells	
num_strat_test_wells = num_sites_char - 1 + num_strat_test_wells_succ_site;
strat_2_inj = 0; %Strat-wells converted to injection wells	wells

injection_fee = 0.25; % lease holders, $/tonne
long_term_stewardship = 0.07;  %long-term stewardship trust fund (state) $/tonne
operational_oversight = 0.01; %operational oversight fund (state) $/tonne

GAA = 0.20; %General and administrative (G&A) Factor
site_selection_cont = 0; %Assessed to account for sites failing
process_contingency = 0.20; %Assessed on all monitoring costs
project_contingency = 0.15; %Assessed on all capital costs

threeD_seismic_survey_cost = 160000; %Basic cost for survey,$/mi2	
threeD_add_cost_processing = .10; % Additional cost for processing field data,% of basic cost for survey

%Factors controlling mass of CO2 to be stored

Aprojmaxnom = 100; %Nom. max. surface area for inject. proj. or largest contiguous area where pore space rights can be acquired; maximum size of AoR

AmaxnomCon = 0; %Control parameter for how to apply the nominal maximum surface area for an injection project
%Options: Nominal max. surf. area for an injection project is applied as follows:		
%0 -- CO2 Plume Uncertainty Area (default)		
%1 -- 3D Seismic Area		
%2 -- max (3D Seis. Area, CO2 Pr. F. AoR)	

Ang3DSeis = 45; %degrees,Angle from CO2 Plume AoR edge to surface needed for 3-D seismic
Ang2DSeis = 45; %degrees,Angle from CO2 Plume AoR edge to surface needed for 2-D seismic

frac_3D = 0.5;  %Fraction of CO2 Plume Uncert. Area that is starting area for 3D seismic monitoring						
frac_2D = 0.5;  %Frac. of CO2 Plume Uncert. Area that provides starting length for 2D seis. monitoring						

PlumePrFAORmult = 10.00; %CO2 Pressure Front AoR Multiplier (applied to CO2 Plume Uncertainty Area),mi

maxCO2mult = 1.250; %Multiplier for annual to maximum daily rate of CO2 injection

qwell_mech_day = 3660; %Max CO2 inject rate per well, tonne/day
qwell_mech_yr = qwell_mech_day*365;%Max CO2 inject rate per well, tonne/yr
grad_Plith=1;	%Lithostatic pressure gradient	psia/ft;	Typical value is 1 psia/ft	
fact_Pfrac=0.60;  %Fracture pressure factor; Typical value is 60%	

Ppumpin = 1200;
Ppumpout = 2200;

apipewell = 0.333;

%Storage Coefficents
tableCoeff = readtable("storageCoeffs.csv");

%Drilling Cost Inputs
drillCosts =readtable('drillingCosts.csv');


%Well Depth Info - Parameters
rathole = 50;
addDepthStrat = 500;
groundwater_depth = 500;
vadose_zone_depth = 10;

%Well Spacing, and number of wells 
well_spacing = [4,0,1,2,4;
                 50,0,1,2,0;
                 2,0,1,2,9999;
                 50,0,1,2,0;
                 4,0,1,5,9999;
                 50,0,1,2,4;
                 1,0,0,0,0;
                 1,0,0,0,0];

well_spacing(:, 6) = max([well_spacing(:, 2), well_spacing(:, 3), zeros(size(well_spacing, 1), 1)], [], 2);


%% Stage duration
%Site Screening

site_screening = 1;

if site_screening == 0
    site_screening_begin = 0;
else
    site_screening_begin = 1;
end

if site_screening == 0
    site_screening_end = 0;
else
    site_screening_end = site_screening;
end

site_screening = [site_screening,site_screening_begin,site_screening_end];

%Site Selection and Characterization

site_selection_characterization = 3;

if site_selection_characterization == 0
    site_selection_characterization_begin = 0;
else
    site_selection_characterization_begin = site_screening_end+1;
end

if site_selection_characterization == 0
    site_selection_characterization_end = 0;
else
    site_selection_characterization_end = site_selection_characterization + site_selection_characterization_begin - 1;
end

site_selection_characterization = [site_selection_characterization, site_selection_characterization_begin,site_selection_characterization_end];

%Permitting and Construction
permitting_construction = 2;

if permitting_construction == 0
    permitting_construction_begin = 0;
elseif site_selection_characterization_begin == 0
    permitting_construction_begin = site_screening_end+1;
else
    permitting_construction_begin = site_selection_characterization_end + 1;
end

if permitting_construction == 0
    permitting_construction_end = 0;
else
    permitting_construction_end = permitting_construction + permitting_construction_begin - 1;
end

permitting_construction = [permitting_construction, permitting_construction_begin, permitting_construction_end];

%Operations
operations = 30;

if operations == 0
    operations_begin = 0;
elseif permitting_construction_begin == 0
    if site_selection_characterization_begin == 0
        operations_begin = site_screening_end+1;
    else
        operations_begin = site_selection_characterization_end+1;
    end
else
    operations_begin = permitting_construction_end + 1;
end

if operations == 0
    operations_end = 0;
else
    operations_end = operations + operations_begin - 1;
end

operations = [operations,operations_begin,operations_end];

%PISC and Site Closure
pisc_closure = 50;

if pisc_closure == 0
    pisc_closure_begin = 0;
else
    pisc_closure_begin = operations_end+1;
end

if pisc_closure == 0
    pisc_closure_end = 0;
else
    pisc_closure_end = pisc_closure + pisc_closure_begin - 1;
end

pisc_closure =  [pisc_closure, pisc_closure_begin, pisc_closure_end];

clear("pisc_closure_end","pisc_closure_begin","operations_begin","operations_end","site_selection_characterization_end","site_selection_characterization_begin","site_screening_end","site_screening_begin",...
    "permitting_construction_end","permitting_construction_begin")

%% Geologic Database
GeolDB = readtable('GeolDB.csv');

%% Activity Inputs & Cost Table
cost_info = readtable('BackEndCosts.xlsx');
cost_info = cost_info(5:494,1:49);
wc_depend = string(table2array(cost_info(:,46)));
pl_depend = string(table2array(cost_info(:,45)));
t_depend = string(table2array(cost_info(:,47)));

cost_info = cost_info(:,1:14);
cost_values = zeros(height(cost_info),4);
cost_categorized = string(table2array(cost_info(:,10)));

% 1.1 Labor Rates ($/hour)
Geologist = 107.23 * (1+GAA);
Engineer = 110.62 * (1+GAA);
Landman = 75 * (1+GAA);
Field = 50 * (1+GAA);

% 1.3 Conversations (acres/mi2)
acres_mi2 = 640;

%% 2 Activity Specific Parameters
% Labor (Hours): Analysis, Modeling, Writing, etc...

% 2.1 Purchase/ Acquire/ Analysis (PAA) Site Screening
%           Quantity| Multiplier | Quantity Mult
periodic_PAA = 1;

cost_values(1:7,2) = site_screening(2);
cost_values(1:7,3) = site_screening(3);
cost_values(1:7,4) = periodic_PAA;


geologic_data =[1500,1,24,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(1,1)=(geologic_data(1)*geologic_data(2)+geologic_data(3)*geologic_data(4)+geologic_data(5)*geologic_data(6)+geologic_data(7)*geologic_data(8)+geologic_data(9)*geologic_data(10))*geologic_data(11)*geologic_data(12)*geologic_data(13)*geologic_data(14);


geophysical_seismic_data = [1500,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(2,1)=(geophysical_seismic_data(1)*geophysical_seismic_data(2)+geophysical_seismic_data(3)*geophysical_seismic_data(4)+geophysical_seismic_data(5)*geophysical_seismic_data(6)+geophysical_seismic_data(7)*geophysical_seismic_data(8)+geophysical_seismic_data(9)*geophysical_seismic_data(10))*geophysical_seismic_data(11)*geophysical_seismic_data(12)*geophysical_seismic_data(13)*geophysical_seismic_data(14);

earthquake_history_data = [1500,1,60,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(3,1)=(earthquake_history_data(1)*earthquake_history_data(2)+earthquake_history_data(3)*earthquake_history_data(4)+earthquake_history_data(5)*earthquake_history_data(6)+earthquake_history_data(7)*earthquake_history_data(8)+earthquake_history_data(9)*earthquake_history_data(10))*earthquake_history_data(11)*earthquake_history_data(12)*earthquake_history_data(13)*earthquake_history_data(14);

geochemical_data = [1500,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(4,1)=(geochemical_data(1)*geochemical_data(2)+geochemical_data(3)*geochemical_data(4)+geochemical_data(5)*geochemical_data(6)+geochemical_data(7)*geochemical_data(8)+geochemical_data(9)*geochemical_data(10))*geochemical_data(11)*geochemical_data(12)*geochemical_data(13)*geochemical_data(14);

geomechanical_data = [1500,1,120,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(5,1)=(geomechanical_data(1)*geomechanical_data(2)+geomechanical_data(3)*geomechanical_data(4)+geomechanical_data(5)*geomechanical_data(6)+geomechanical_data(7)*geomechanical_data(8)+geomechanical_data(9)*geomechanical_data(10))*geomechanical_data(11)*geomechanical_data(12)*geomechanical_data(13)*geomechanical_data(14);

land_data = [1500,1,0,Geologist,0,Engineer,500,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(6,1)=(land_data(1)*land_data(2)+land_data(3)*land_data(4)+land_data(5)*land_data(6)+land_data(7)*land_data(8)+land_data(9)*land_data(10))*land_data(11)*land_data(12)*land_data(13)*land_data(14);

software = [1500,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(7,1)=(software(1)*software(2)+software(3)*software(4)+software(5)*software(6)+software(7)*software(8)+software(9)*software(10))*software(11)*software(12)*software(13)*software(14);


% 2.2 Purchase/ Acquire/ Analysis (PAA) Site Selection & Site
% Characterization, PAA not previously obtained
periodic_PAA = 1;
cost_values(8:14,2) = site_selection_characterization(2);
cost_values(8:14,3) = site_selection_characterization(3);
cost_values(8:14,4) = periodic_PAA;

geologic_data =[1500,1,24,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(8,1)=(geologic_data(1)*geologic_data(2)+geologic_data(3)*geologic_data(4)+geologic_data(5)*geologic_data(6)+geologic_data(7)*geologic_data(8)+geologic_data(9)*geologic_data(10))*geologic_data(11)*geologic_data(12)*geologic_data(13)*geologic_data(14);


geophysical_seismic_data = [1500,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(9,1)=(geophysical_seismic_data(1)*geophysical_seismic_data(2)+geophysical_seismic_data(3)*geophysical_seismic_data(4)+geophysical_seismic_data(5)*geophysical_seismic_data(6)+geophysical_seismic_data(7)*geophysical_seismic_data(8)+geophysical_seismic_data(9)*geophysical_seismic_data(10))*geophysical_seismic_data(11)*geophysical_seismic_data(12)*geophysical_seismic_data(13)*geophysical_seismic_data(14);

earthquake_history_data = [1500,1,60,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(10,1)=(earthquake_history_data(1)*earthquake_history_data(2)+earthquake_history_data(3)*earthquake_history_data(4)+earthquake_history_data(5)*earthquake_history_data(6)+earthquake_history_data(7)*earthquake_history_data(8)+earthquake_history_data(9)*earthquake_history_data(10))*earthquake_history_data(11)*earthquake_history_data(12)*earthquake_history_data(13)*earthquake_history_data(14);

geochemical_data = [1500,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(11,1)=(geochemical_data(1)*geochemical_data(2)+geochemical_data(3)*geochemical_data(4)+geochemical_data(5)*geochemical_data(6)+geochemical_data(7)*geochemical_data(8)+geochemical_data(9)*geochemical_data(10))*geochemical_data(11)*geochemical_data(12)*geochemical_data(13)*geochemical_data(14);

geomechanical_data = [1500,1,120,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(12,1)=(geomechanical_data(1)*geomechanical_data(2)+geomechanical_data(3)*geomechanical_data(4)+geomechanical_data(5)*geomechanical_data(6)+geomechanical_data(7)*geomechanical_data(8)+geomechanical_data(9)*geomechanical_data(10))*geomechanical_data(11)*geomechanical_data(12)*geomechanical_data(13)*geomechanical_data(14);

land_data = [1500,1,0,Geologist,0,Engineer,500,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(13,1)=(land_data(1)*land_data(2)+land_data(3)*land_data(4)+land_data(5)*land_data(6)+land_data(7)*land_data(8)+land_data(9)*land_data(10))*land_data(11)*land_data(12)*land_data(13)*land_data(14);

software = [100000,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(14,1)=(software(1)*software(2)+software(3)*software(4)+software(5)*software(6)+software(7)*software(8)+software(9)*software(10))*software(11)*software(12)*software(13)*software(14);

% Testing 
periodic_testing = 3;
cost_values(15:17,2) = site_selection_characterization(2);
cost_values(15:17,3) = site_selection_characterization(3);
cost_values(15:17,4) = periodic_testing;

periodic_survey_planning = [10000,NaN,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(15,1)=(periodic_survey_planning(1)*periodic_survey_planning(2)+periodic_survey_planning(3)*periodic_survey_planning(4)+periodic_survey_planning(5)*periodic_survey_planning(6)+periodic_survey_planning(7)*periodic_survey_planning(8)+periodic_survey_planning(9)*periodic_survey_planning(10))*periodic_survey_planning(11)*periodic_survey_planning(12)*periodic_survey_planning(13)*periodic_survey_planning(14);

periodic_CIR = [10000,NaN,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(16,1)=(periodic_CIR(1)*periodic_CIR(2)+periodic_CIR(3)*periodic_CIR(4)+periodic_CIR(5)*periodic_CIR(6)+periodic_CIR(7)*periodic_CIR(8)+periodic_CIR(9)*periodic_CIR(10))*periodic_CIR(11)*periodic_CIR(12)*periodic_CIR(13)*periodic_CIR(14);

labratory = [0,0,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(17,1)=(labratory(1)*labratory(2)+labratory(3)*labratory(4)+labratory(5)*labratory(6)+labratory(7)*labratory(8)+labratory(9)*labratory(10))*labratory(11)*labratory(12)*labratory(13)*labratory(14);

% 2.3 Preparing 
periodic_prepare = 1;
cost_values(18:26,2) = site_selection_characterization(2);
cost_values(18:26,3) = site_selection_characterization(3);
cost_values(18:26,4) = periodic_prepare;

cost = [0,1,24,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(18,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,60,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(19,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [10300,1,240,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(20,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,12,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(21,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,12,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(22,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,36,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(23,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,60,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(24,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,240,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(25,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(26,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%2.4 Modeling
periodic_modeling = 1;
cost_values(27:34,2) = site_selection_characterization(2);
cost_values(27:34,3) = site_selection_characterization(3);
cost_values(27:34,4) = periodic_modeling;

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(27,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(28,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,250,Geologist,500,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(29,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,24,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(30,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(31,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(32,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(33,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(34,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%Corrective Action Planning
periodic_CA = 1;
cost_values(35:38,2) = site_selection_characterization(2);
cost_values(35:38,3) = site_selection_characterization(3);
cost_values(35:38,4) = periodic_CA;

cost = [0,1,24,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(35,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(36,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,6,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(37,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(38,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%2.6 Front-End Engineering and Design
periodic_Front_Eng_Des = 1;
cost_values(39:43,2) = site_selection_characterization(2);
cost_values(39:43,3) = site_selection_characterization(3);
cost_values(39:43,4) = periodic_Front_Eng_Des;

cost = [207000,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(39,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [20700,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(40,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [100000,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(41,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [41400,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(42,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [5200,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1+process_contingency,1+project_contingency];
cost_values(43,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%2.7 Preparation of plans for Class VI permit
periodic_prep = 1;
cost_values(44:49,2) = site_selection_characterization(2);
cost_values(44:49,3) = site_selection_characterization(3);
cost_values(44:49,4) = periodic_prep;

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(44,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [30000,1,20,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(45,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,120,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(46,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [30000,1,20,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(47,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [20000,1,15,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(48,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,4,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(49,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%2.8 Land Leasing 
periodic_land_leasing = 3;
cost_values(50:55,2) = site_selection_characterization(2);
cost_values(50:55,3) = site_selection_characterization(3);
cost_values(50:55,4) = periodic_land_leasing;

cost = [0,1,0,Geologist,0,Engineer,2000,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(50,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(51,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,20,Geologist,20,Engineer,500,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(52,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(53,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [Lease_bonus,640,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(54,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(55,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%2.9 Permits - Permitting & Construction
periodic_permit = 1;
cost_values(56:70,2) = permitting_construction(2);
cost_values(56:70,3) = permitting_construction(2);
cost_values(56:70,4) = periodic_permit;

cost = [10400,1,0,Geologist,96,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(56,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(57,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(58,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(59,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(60,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(61,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(62,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);


cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(63,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(64,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(65,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(68,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [6000,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(69,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(70,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%2.10 Injection well drilling
periodic_injection = 1;
cost_values(71:77,2) = permitting_construction(2);
cost_values(71:77,3) = permitting_construction(3);
cost_values(71:77,4) = periodic_injection;

cost = [0,1,40,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(71,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,20,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(72,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,20,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(73,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,20,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(74,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,20,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(75,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,20,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(76,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,20,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(77,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%2.11 Subpart RR - Prepaaration of Monitoring, Verification, and Reporting
%on (MVR) plan
periodic_subpart = 1;
cost_values(78,2) = permitting_construction(2);
cost_values(78,3) = permitting_construction(3);
cost_values(78,4) = periodic_subpart;

cost = [33000,1,400,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(78,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%2.12 Gathering Field Data - Operations & PISC
cost_values(79:2:81,2) = operations(2);
cost_values(79:2:81,3) = operations(3);
cost_values(80:2:82,2) = pisc_closure(2);
cost_values(80:2:82,3) = pisc_closure(3);
cost_values(79:80,4) = 4;
cost_values(81:82,4) = 1;

cost = [0,1,0,Geologist,0,Engineer,0,Landman,10,Field,1,1,1,1+project_contingency];
cost_values(79,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,10,Field,1,1,1,1+project_contingency];
cost_values(80,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(81,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(82,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%2.13 Corrective Action - Remediating Deep Well
periodic_subpart = 5;
cost_values(83,2) = operations(2);
cost_values(83,3) = operations(3);
cost_values(83,4) = periodic_subpart;

%Cleanout | LOG | Replug | based on well count
cost = [31200,nan,11400,nan,13500,nan,0,0,0,0,1,1,1,1];
cost_values(83,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%3.1 Fees per tonne CO2
periodic_fees = 1;
cost_values(84:86,2) = operations(2);
cost_values(84:86,3) = operations(3);
cost_values(84:86,4) = periodic_fees;

cost = [injection_fee,nan,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(84,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [long_term_stewardship,nan,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(85,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [operational_oversight,nan,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(86,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%3.2 Fees, one-time (other expenses)
periodic_one = 1;
cost_values(87:4:91,2) = site_selection_characterization(2);
cost_values(87:4:91,3) = site_selection_characterization(2);
cost_values(87:4:91,4) = periodic_one;

cost_values(88:4:92,2) = permitting_construction(2);
cost_values(88:4:92,3) = permitting_construction(2);
cost_values(88:4:92,4) = periodic_one;

cost_values(89:4:93,2) = operations(2);
cost_values(89:4:93,3) = operations(2);
cost_values(89:4:93,4) = periodic_one;

cost_values(94:1:96,2) = operations(2);
cost_values(94:1:96,3) = operations(2);
cost_values(94:1:96,4) = periodic_one;

cost_values(90,2) = pisc_closure(2);
cost_values(90,3) = pisc_closure(2);
cost_values(90,4) = periodic_one;

cost = [100000,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(87,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [100000,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(88,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [100000,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(89,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [100000,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(90,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [10400,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(91,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [10400,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(92,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [10400,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(93,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [1000,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(94,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [500,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(95,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [500,1,0,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(96,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%3.3 Periodic Reports
cost_values(97,2) = operations(2);
cost_values(97,3) = operations(3);
cost_values(97,4) = 1;

cost_values(98,2) = pisc_closure(2);
cost_values(98,3) = pisc_closure(3);
cost_values(98,4) = 1;

cost_values(99,2) = operations(2);
cost_values(99,3) = operations(3);
cost_values(99,4) = 1;

cost_values(100,2) = pisc_closure(2);
cost_values(100,3) = pisc_closure(3);
cost_values(100,4) = 1;

cost_values(101,2) = operations(2);
cost_values(101,3) = operations(3);
cost_values(101,4) = 5;

cost_values(102,2) = pisc_closure(2);
cost_values(102,3) = pisc_closure(3);
cost_values(102,4) = 1;

cost_values(103,2) = operations(2);
cost_values(103,3) = operations(3);
cost_values(103,4) = 5;

cost_values(104,2) = pisc_closure(2);
cost_values(104,3) = pisc_closure(3);
cost_values(104,4) = 1;

cost_values(105,2) = operations(2);
cost_values(105,3) = operations(3);
cost_values(105,4) = 5;

cost_values(106,2) = pisc_closure(2);
cost_values(106,3) = pisc_closure(3);
cost_values(106,4) = 1;

cost_values(107,2) = operations(2);
cost_values(107,3) = operations(3);
cost_values(107,4) = 1;

cost_values(108,2) = pisc_closure(2);
cost_values(108,3) = pisc_closure(3);
cost_values(108,4) = 1;

cost_values(109,2) = operations(2);
cost_values(109,3) = operations(3);
cost_values(109,4) = 5;

cost_values(110,2) = pisc_closure(2);
cost_values(110,3) = pisc_closure(3);
cost_values(110,4) = 1;

cost_values(111,2) = operations(3);
cost_values(111,3) = operations(3);
cost_values(111,4) = 1;

cost_values(112:113,2) = pisc_closure(3);
cost_values(112:113,3) = pisc_closure(3);
cost_values(112:113,4) = 1;

cost = [0,1,0,Geologist,72,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(97,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,72,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(98,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,100,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(99,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,100,Geologist,0,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(100,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,84,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(101,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,84,Engineer,0,Landman,0,Field,0,1,1,1+project_contingency];
cost_values(102,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,83,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(103,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,83,Engineer,0,Landman,0,Field,0,1,1,1+project_contingency];
cost_values(104,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,83,Engineer,0,Landman,0,Field,1,1,1,1+project_contingency];
cost_values(105,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,83,Engineer,0,Landman,0,Field,0,1,1,1+project_contingency];
cost_values(106,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,4,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(107,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,4,Engineer,0,Landman,0,Field,0,1,1,1];
cost_values(108,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,40,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(109,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,40,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(110,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,120,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(111,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,0,Geologist,120,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(112,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost = [0,1,120,Geologist,120,Engineer,0,Landman,0,Field,1,1,1,1];
cost_values(113,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%3.4 Fluid Samples
cost_sample_deep_mon_wells = 5000;

cost_values(114,2) = operations(2);
cost_values(114,3) = operations(3);
cost_values(114,4) = 1;

cost = [cost_sample_deep_mon_wells,4,200,4,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(114,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);


cost_values(115,2) = pisc_closure(2);
cost_values(115,3) = pisc_closure(3);
cost_values(115,4) = 1;

cost = [cost_sample_deep_mon_wells,4,200,4,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(115,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(116,2) = operations(2);
cost_values(116,3) = operations(3);
cost_values(116,4) = 1;

cost = [cost_sample_deep_mon_wells,8,200,8,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(116,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(117,2) = pisc_closure(2);
cost_values(117,3) = pisc_closure(3);
cost_values(117,4) = 1;

cost = [cost_sample_deep_mon_wells,8,200,8,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(117,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(118,2) = operations(2);
cost_values(118,3) = operations(3);
cost_values(118,4) = 1;

cost = [cost_sample_deep_mon_wells,4,200,4,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(118,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(119,2) = pisc_closure(2);
cost_values(119,3) = pisc_closure(3);
cost_values(119,4) = 1;

cost = [cost_sample_deep_mon_wells,4,200,4,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(119,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(120,2) = operations(2);
cost_values(120,3) = operations(3);
cost_values(120,4) = 1;

cost = [1000,4,200,16,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(120,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(121,2) = pisc_closure(2);
cost_values(121,3) = pisc_closure(3);
cost_values(121,4) = 1;

cost = [1000,4,200,16,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(121,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(122,2) = operations(2);
cost_values(122,3) = operations(3);
cost_values(122,4) = 1;

cost = [0.05,nan,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(122,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(123,2) = operations(2);
cost_values(123,3) = operations(3);
cost_values(123,4) = 1;

cost = [1,500,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(123,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(124,2) = pisc_closure(2);
cost_values(124,3) = pisc_closure(3);
cost_values(124,4) = 1;

cost = [1,500,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(124,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(125,2) = operations(2);
cost_values(125,3) = operations(3);
cost_values(125,4) = 1;

cost = [1,500,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(125,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(126,2) = pisc_closure(2);
cost_values(126,3) = pisc_closure(3);
cost_values(126,4) = 1;

cost = [1,500,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(126,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(127,2) = operations(2);
cost_values(127,3) = operations(3);
cost_values(127,4) = 1;

cost = [1,500,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(127,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(128,2) = pisc_closure(2);
cost_values(128,3) = pisc_closure(3);
cost_values(128,4) = 1;

cost = [1,500,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(128,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%3.5 Gas Samples
flux_chambrs_inj_well = 20;

cost_values(129,2) = operations(2);
cost_values(129,3) = operations(3);
cost_values(129,4) = 1;

cost = [4,100,200,4,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(129,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(130,2) = pisc_closure(2);
cost_values(130,3) = pisc_closure(3);
cost_values(130,4) = 1;

cost = [4,100,200,4,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(130,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(131,2) = site_selection_characterization(2);
cost_values(131,3) = site_selection_characterization(3);
cost_values(131,4) = 1;

cost = [4,nan,nan,25,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(131,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(132,2) = permitting_construction(2);
cost_values(132,3) = permitting_construction(3);
cost_values(132,4) = 1;

cost = [4,nan,nan,25,0,0,0,0,0,0,0,1,1+process_contingency,1];
cost_values(132,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(133,2) = operations(2);
cost_values(133,3) = operations(3);
cost_values(133,4) = 1;

cost = [4,nan,nan,25,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(133,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(134,2) = pisc_closure(2);
cost_values(134,3) = pisc_closure(3);
cost_values(134,4) = 1;

cost = [4,nan,nan,25,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(134,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%3.6 Aerial/Satellite Survey

cost_values(135,2) = site_selection_characterization(2);
cost_values(135,3) = site_selection_characterization(3);
cost_values(135,4) = 1;

cost = [3100,1,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1+project_contingency];
cost_values(135,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(136,2) = permitting_construction(2);
cost_values(136,3) = permitting_construction(3);
cost_values(136,4) = 1;

cost = [3100,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(136,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(137,2) = operations(2);
cost_values(137,3) = operations(3);
cost_values(137,4) = 1;

cost = [3100,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(137,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(138,2) = pisc_closure(2);
cost_values(138,3) = pisc_closure(3);
cost_values(138,4) = 1;

cost = [3100,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(138,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%--------

cost_values(139,2) = site_selection_characterization(2);
cost_values(139,3) = site_selection_characterization(3);
cost_values(139,4) = 1;

cost = [5200,1,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1+project_contingency];
cost_values(139,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(140,2) = permitting_construction(2);
cost_values(140,3) = permitting_construction(3);
cost_values(140,4) = 1;

cost = [5200,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(140,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(141,2) = operations(2);
cost_values(141,3) = operations(3);
cost_values(141,4) = 1;

cost = [5200,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(141,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(142,2) = pisc_closure(2);
cost_values(142,3) = pisc_closure(3);
cost_values(142,4) = 1;

cost = [5200,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(142,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%-----------

cost_values(143,2) = site_selection_characterization(2);
cost_values(143,3) = site_selection_characterization(3);
cost_values(143,4) = 1;

cost = [5200,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(143,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(144,2) = permitting_construction(2);
cost_values(144,3) = permitting_construction(3);
cost_values(144,4) = 1;

cost = [5200,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(144,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(145,2) = operations(2);
cost_values(145,3) = operations(3);
cost_values(145,4) = 1;

cost = [5200,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(145,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(146,2) = pisc_closure(2);
cost_values(146,3) = pisc_closure(3);
cost_values(146,4) = 1;

cost = [5200,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(146,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%-----------

cost_values(147,2) = site_selection_characterization(2);
cost_values(147,3) = site_selection_characterization(3);
cost_values(147,4) = 1;

cost = [5000,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(147,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(148,2) = permitting_construction(2);
cost_values(148,3) = permitting_construction(3);
cost_values(148,4) = 1;

cost = [5000,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(148,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(149,2) = operations(2);
cost_values(149,3) = operations(3);
cost_values(149,4) = 1;

cost = [5000,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(149,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(150,2) = pisc_closure(2);
cost_values(150,3) = pisc_closure(3);
cost_values(150,4) = 1;

cost = [5000,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(150,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%-----------

cost_values(151,2) = site_selection_characterization(2);
cost_values(151,3) = site_selection_characterization(3);
cost_values(151,4) = 1;

cost = [000,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(151,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(152,2) = permitting_construction(2);
cost_values(152,3) = permitting_construction(3);
cost_values(152,4) = 1;

cost = [000,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(152,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(153,2) = operations(2);
cost_values(153,3) = operations(3);
cost_values(153,4) = 1;

cost = [000,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(153,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(154,2) = pisc_closure(2);
cost_values(154,3) = pisc_closure(3);
cost_values(154,4) = 1;

cost = [000,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(154,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%----

cost_values(155,2) = site_selection_characterization(2);
cost_values(155,3) = site_selection_characterization(3);
cost_values(155,4) = 1;

cost = [000,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(155,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(156,2) = permitting_construction(2);
cost_values(156,3) = permitting_construction(3);
cost_values(156,4) = 1;

cost = [000,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(156,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(157,2) = operations(2);
cost_values(157,3) = operations(3);
cost_values(157,4) = 1;

cost = [000,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(157,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(158,2) = pisc_closure(2);
cost_values(158,3) = pisc_closure(3);
cost_values(158,4) = 1;

cost = [000,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(158,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%--------

cost_values(159,2) = site_selection_characterization(2);
cost_values(159,3) = site_selection_characterization(3);
cost_values(159,4) = 1;

cost = [415,1,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1+project_contingency];
cost_values(159,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(160,2) = permitting_construction(2);
cost_values(160,3) = permitting_construction(3);
cost_values(160,4) = 1;

cost = [415,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(160,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(161,2) = operations(2);
cost_values(161,3) = operations(3);
cost_values(161,4) = 1;

cost = [415,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(161,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(162,2) = pisc_closure(2);
cost_values(162,3) = pisc_closure(3);
cost_values(162,4) = 1;

cost = [415,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(162,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%------------

cost_values(163,2) = site_selection_characterization(2);
cost_values(163,3) = site_selection_characterization(3);
cost_values(163,4) = 1;

cost = [11160,1,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1+project_contingency];
cost_values(163,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(164,2) = permitting_construction(2);
cost_values(164,3) = permitting_construction(3);
cost_values(164,4) = 1;

cost = [11160,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(164,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(165,2) = operations(2);
cost_values(165,3) = operations(3);
cost_values(165,4) = 1;

cost = [11160,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(165,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(166,2) = pisc_closure(2);
cost_values(166,3) = pisc_closure(3);
cost_values(166,4) = 1;

cost = [11160,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(166,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%---------

cost_values(167,2) = site_selection_characterization(2);
cost_values(167,3) = site_selection_characterization(3);
cost_values(167,4) = 1;

cost = [11160,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(167,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(168,2) = permitting_construction(2);
cost_values(168,3) = permitting_construction(3);
cost_values(168,4) = 1;

cost = [11160,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(168,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(169,2) = operations(2);
cost_values(169,3) = operations(3);
cost_values(169,4) = 1;

cost = [11160,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(169,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(170,2) = pisc_closure(2);
cost_values(170,3) = pisc_closure(3);
cost_values(170,4) = 1;

cost = [11160,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(170,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%---------

cost_values(171,2) = site_selection_characterization(2);
cost_values(171,3) = site_selection_characterization(3);
cost_values(171,4) = 1;

cost = [6250,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(171,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(172,2) = permitting_construction(2);
cost_values(172,3) = permitting_construction(3);
cost_values(172,4) = 1;

cost = [6250,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(172,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(173,2) = operations(2);
cost_values(173,3) = operations(3);
cost_values(173,4) = 1;

cost = [6250,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(173,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(174,2) = pisc_closure(2);
cost_values(174,3) = pisc_closure(3);
cost_values(174,4) = 1;

cost = [6250,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(174,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%-----------

cost_values(175,2) = site_selection_characterization(2);
cost_values(175,3) = site_selection_characterization(3);
cost_values(175,4) = 1;

cost = [0,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(175,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(176,2) = permitting_construction(2);
cost_values(176,3) = permitting_construction(3);
cost_values(176,4) = 1;

cost = [0,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(176,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(177,2) = operations(2);
cost_values(177,3) = operations(3);
cost_values(177,4) = 1;

cost = [0,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(177,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(178,2) = pisc_closure(2);
cost_values(178,3) = pisc_closure(3);
cost_values(178,4) = 1;

cost = [0,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(178,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%---------------

cost_values(179,2) = site_selection_characterization(2);
cost_values(179,3) = site_selection_characterization(3);
cost_values(179,4) = 1;

cost = [0,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(179,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(180,2) = permitting_construction(2);
cost_values(180,3) = permitting_construction(3);
cost_values(180,4) = 1;

cost = [0,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(180,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(181,2) = operations(2);
cost_values(181,3) = operations(3);
cost_values(181,4) = 1;

cost = [0,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(181,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(182,2) = pisc_closure(2);
cost_values(182,3) = pisc_closure(3);
cost_values(182,4) = 1;

cost = [0,1,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(182,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%3.7 Geophysical Survey - 3D Suface Seismic

cost_values(183,2) = 3;
cost_values(183,3) = site_selection_characterization(3);
cost_values(183,4) = 2;

cost = [threeD_seismic_survey_cost,1,0,0,0,0,0,0,0,0,1,1+threeD_add_cost_processing,1+process_contingency,1+project_contingency];
cost_values(183,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(184,2) = permitting_construction(2);
cost_values(184,3) = permitting_construction(3);
cost_values(184,4) = 1;

cost = [threeD_seismic_survey_cost,1,0,0,0,0,0,0,0,0,0,1+threeD_add_cost_processing,1+process_contingency,1+project_contingency];
cost_values(184,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(185,2) = operations(2);
cost_values(185,3) = operations(3);
cost_values(185,4) = 5;

cost = [threeD_seismic_survey_cost,1,0,0,0,0,0,0,0,0,1,1+threeD_add_cost_processing,1+process_contingency,1+project_contingency];
cost_values(185,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(186,2) = pisc_closure(2);
cost_values(186,3) = pisc_closure(3);
cost_values(186,4) = 5;

cost = [threeD_seismic_survey_cost,1,0,0,0,0,0,0,0,0,1,1+threeD_add_cost_processing,1+process_contingency,1+project_contingency];
cost_values(186,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%3.8 Geophysical Survey - 2D Surface Seismic

cost_values(187,2) = 2;
cost_values(187,3) = 2;
cost_values(187,4) = 1;

cost = [26000,num_sites_char*num_2D_seismic_lines,0,0,0,0,0,0,0,0,1,1+threeD_add_cost_processing,1+process_contingency,1+project_contingency];
cost_values(187,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(188,2) = permitting_construction(2);
cost_values(188,3) = permitting_construction(3);
cost_values(188,4) = 1;

cost = [26000,0,0,0,0,0,0,0,0,0,0,1+threeD_add_cost_processing,1+process_contingency,1+project_contingency];
cost_values(188,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(189,2) = operations(2);
cost_values(189,3) = operations(3);
cost_values(189,4) = 5;

cost = [26000,0,0,0,0,0,0,0,0,0,1,1+threeD_add_cost_processing,1+process_contingency,1+project_contingency];
cost_values(189,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(190,2) = pisc_closure(2);
cost_values(190,3) = pisc_closure(3);
cost_values(190,4) = 5;

cost = [26000,0,0,0,0,0,0,0,0,0,1,1+threeD_add_cost_processing,1+process_contingency,1+project_contingency];
cost_values(190,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%-----

cost_values(191,2) = 2;
cost_values(191,3) = 2;
cost_values(191,4) = 1;

cost = [0,num_sites_char*num_2D_seismic_lines,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(191,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(192,2) = permitting_construction(2);
cost_values(192,3) = permitting_construction(3);
cost_values(192,4) = 1;

cost = [0,0,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(192,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(193,2) = operations(2);
cost_values(193,3) = operations(3);
cost_values(193,4) = 1;

cost = [0,0,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(193,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(194,2) = pisc_closure(2);
cost_values(194,3) = pisc_closure(3);
cost_values(194,4) = 1;

cost = [0,0,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(194,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(195,2) = site_selection_characterization(2);
cost_values(195,3) = site_selection_characterization(3);
cost_values(195,4) = 3;

cost = [25000,1,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1+project_contingency];
cost_values(195,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%3.9 Wellbore Seismic: (For in Reservoir and Above Seal Wells)
cost_values(196,2) = site_selection_characterization(2);
cost_values(196,3) = site_selection_characterization(3);
cost_values(196,4) = 1;

cost = [52000,1,0,0,0,0,0,0,0,0,0,1+threeD_add_cost_processing,1+process_contingency,1+project_contingency];
cost_values(196,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(197,2) = permitting_construction(2);
cost_values(197,3) = permitting_construction(3);
cost_values(197,4) = 1;

cost = [52000,1,0,0,0,0,0,0,0,0,0,1+threeD_add_cost_processing,1+process_contingency,1+project_contingency];
cost_values(197,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(198,2) = operations(2);
cost_values(198,3) = operations(3);
cost_values(198,4) = 1;

cost = [52000,1,0,0,0,0,0,0,0,0,0,1+threeD_add_cost_processing,1+process_contingency,1+project_contingency];
cost_values(198,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(199,2) = pisc_closure(2);
cost_values(199,3) = pisc_closure(3);
cost_values(199,4) = 1;

cost = [52000,1,0,0,0,0,0,0,0,0,0,1+threeD_add_cost_processing,1+process_contingency,1+project_contingency];
cost_values(199,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%------------

cost_values(200,2) = site_selection_characterization(2);
cost_values(200,3) = site_selection_characterization(3);
cost_values(200,4) = 1;

cost = [52000,3,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(200,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(201,2) = permitting_construction(2);
cost_values(201,3) = permitting_construction(3);
cost_values(201,4) = 1;

cost = [52000,3,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(201,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(202,2) = operations(2);
cost_values(202,3) = operations(3);
cost_values(202,4) = 1;

cost = [52000,3,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(202,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(203,2) = pisc_closure(2);
cost_values(203,3) = pisc_closure(3);
cost_values(203,4) = 1;

cost = [52000,3,0,0,0,0,0,0,0,0,0,1,1+process_contingency,1+project_contingency];
cost_values(203,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%3.10 Electrical & 3.11 Other geophysical are all zeros so they are skipped
%204 - 245
%3.12 Atmospheric

cost_values(246,2) = operations(2);
cost_values(246,3) = operations(3);
cost_values(246,4) = 1;

cost = [10000,5,0,0,0,0,0,0,0,0,1,1+.10,1+process_contingency,1];
cost_values(246,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(247,2) = pisc_closure(2);
cost_values(247,3) = pisc_closure(3);
cost_values(247,4) = 1;

cost = [10000,5,0,0,0,0,0,0,0,0,1,1+.10,1+process_contingency,1];
cost_values(247,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);


%248-249 = 0


cost_values(250,2) = operations(2);
cost_values(250,3) = operations(3);
cost_values(250,4) = 1;

cost = [35000,5,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1+project_contingency];
cost_values(250,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(251,2) = pisc_closure(2);
cost_values(251,3) = pisc_closure(3);
cost_values(251,4) = 1;

cost = [35000,5,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1+project_contingency];
cost_values(251,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%252-253 =0

cost_values(254,2) = operations(2);
cost_values(254,3) = operations(3);
cost_values(254,4) = 1;

cost = [10000,1,0,0,0,0,0,0,0,0,1,1,1+process_contingency,1];
cost_values(254,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%255-275 = 0

cost_values(276,2) = site_selection_characterization(2);
cost_values(276,3) = site_selection_characterization(3);
cost_values(276,4) = 3;

cost = [70000,5,40,Geologist,0,0,0,0,0,0,1,1,1+process_contingency,1+project_contingency];
cost_values(276,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%3.13 Injection Well Monitoring
%277 - 282 = 0
cost_values(283,2) = operations(2);
cost_values(283,3) = operations(3);
cost_values(283,4) = 5;

cost = [0,0,2070,1,0,0,0,0,0,0,1,1,1,1];
cost_values(283,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(284,2) = operations(2);
cost_values(284,3) = operations(3);
cost_values(284,4) = 1;

cost = [200,16,4,100,4,0,0,0,0,0,1,1,1,1];
cost_values(284,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%285 - 286 =0

cost_values(287,2) = operations(2);
cost_values(287,3) = operations(3);
cost_values(287,4) = 1;

cost = [0,1,6,Engineer,0,0,0,0,0,0,1,1,1,1];
cost_values(287,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

%3.14 Data Analysis and Modeling 

cost_values(288,2) = operations(2);
cost_values(288,3) = operations(3);
cost_values(288,4) = 1;

cost = [25000,1,0,0,0,0,0,0,0,0,1,1,1,1];
cost_values(288,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(289,2) = pisc_closure(2);
cost_values(289,3) = pisc_closure(3);
cost_values(289,4) = 1;

cost = [25000,1,0,0,0,0,0,0,0,0,1,1,1,1];
cost_values(289,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(290,2) = operations(2);
cost_values(290,3) = operations(3);
cost_values(290,4) = 5;

cost = [25000,1,0,0,0,0,0,0,0,0,1,1,1,1];
cost_values(290,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(291,2) = pisc_closure(2);
cost_values(291,3) = pisc_closure(3);
cost_values(291,4) = 5;

cost = [25000,1,0,0,0,0,0,0,0,0,1,1,1,1];
cost_values(291,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(292,2) = operations(2);
cost_values(292,3) = operations(3);
cost_values(292,4) = 1;

cost = [25000,1,0,0,0,0,0,0,0,0,1,1,1,1];
cost_values(292,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(293,2) = pisc_closure(2);
cost_values(293,3) = pisc_closure(3);
cost_values(293,4) = 1;

cost = [25000,1,0,0,0,0,0,0,0,0,1,1,1,1];
cost_values(293,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(294,2) = operations(2);
cost_values(294,3) = operations(3);
cost_values(294,4) = 5;

cost = [25000,1,0,0,0,0,0,0,0,0,1,1,1,1];
cost_values(294,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(295,2) = pisc_closure(2);
cost_values(295,3) = pisc_closure(3);
cost_values(295,4) = 5;

cost = [25000,1,0,0,0,0,0,0,0,0,1,1,1,1];
cost_values(295,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(296,2) = site_selection_characterization(2);
cost_values(296,3) = 2;
cost_values(296,4) = 1;

cost = [0,1,0,0,0,0,0,0,0,0,1,1,1,1];
cost_values(296,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

% 4.1 Well Drilling Costs - Permits
cost_values(297,2) = 2;
cost_values(297,3) = 2;
cost_values(297,4) = 1;

cost = [100,1,0,0,0,0,0,0,0,0,1,1,1,1+project_contingency];
cost_values(297,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(298,2) = permitting_construction(3);
cost_values(298,3) = permitting_construction(3);
cost_values(298,4) = 1;

cost = [100,1,0,0,0,0,0,0,0,0,1,1,1,1+project_contingency];
cost_values(298,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(299,2) = operations(2);
cost_values(299,3) = operations(3);
cost_values(299,4) = 1;

cost = [100,1,0,0,0,0,0,0,0,0,1,1,1,1+project_contingency];
cost_values(299,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(300,2) = operations(2);
cost_values(300,3) = operations(3);
cost_values(300,4) = 1;

cost = [100,1,0,0,0,0,0,0,0,0,1,1,1,1+project_contingency];
cost_values(300,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(301,2) = operations(2);
cost_values(301,3) = operations(3);
cost_values(301,4) = 1;

cost = [100,1,0,0,0,0,0,0,0,0,1,1,1,1+project_contingency];
cost_values(301,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(302,2) = operations(2);
cost_values(302,3) = operations(3);
cost_values(302,4) = 1;

cost = [100,1,0,0,0,0,0,0,0,0,1,1,1,1+project_contingency];
cost_values(302,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(303,2) = operations(2);
cost_values(303,3) = operations(3);
cost_values(303,4) = 1;

cost = [100,1,0,0,0,0,0,0,0,0,1,1,1,1+project_contingency];
cost_values(303,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(304,2) = operations(2);
cost_values(304,3) = operations(3);
cost_values(304,4) = 1;

cost = [100,1,0,0,0,0,0,0,0,0,1,1,1,1+project_contingency];
cost_values(304,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);

cost_values(305,2) = operations(2);
cost_values(305,3) = operations(3);
cost_values(305,4) = 1;

cost = [100,1,0,0,0,0,0,0,0,0,1,1,1,1+project_contingency];
cost_values(305,1)=(cost(1)*cost(2)+cost(3)*cost(4)+cost(5)*cost(6)+cost(7)*cost(8)+cost(9)*cost(10))*cost(11)*cost(12)*cost(13)*cost(14);


save("/Users/patrickconnor/Documents/MATLAB/Graduate School/Research/CCS Model V3/Storage_Data")





