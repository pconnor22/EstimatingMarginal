function  [plume_area_other,monitoring_wells_reservoir,monitoring_wells_dual,monitoring_wells_above,monitoring_ground_water,monitoring_vadose] = plume_well_schedule(site_selection_characterization,permitting_construction,operations, pisc_closure,...
    PlumeUnArmult,ACO2plz,PlumePrFAORmult,Ang3DSeis,Ang2DSeis,frac_3D,frac_2D,ACO2plUn,Ltop,htot_ft,num_strat_test_wells,...
    strat_2_inj,Nwell_fin,well_spacing)

%{ 
Timelines:
Monitoring Wells	In Reservoir	7	36
	Above Seal	7	36
	Dual Completed	7	36
	Groundwater	7	36
	Vadose Zone	7	36

Injection Wells		6	6
Strat Test Wells		2	2
Water Production		7	36
Water Disposal		7	36
%}

strat=[site_selection_characterization(2),site_selection_characterization(2)];
inj = [permitting_construction(3),permitting_construction(3)];
monitoring = [operations(2),operations(3)];


Lbot = (Ltop + htot_ft)/5280; %feet converted to miles,depth to bottom of formation

CO2_Pressure_Front_AoR = (ACO2plUn*PlumePrFAORmult);

max_3D_seismic_A = pi*(sqrt(ACO2plUn/pi)+Lbot*tan(Ang3DSeis*pi/180))^2;%Maximum 3D Seismic Area

max_2D_seismic_L=2*(sqrt(ACO2plUn/pi)+Lbot*tan(Ang2DSeis*pi/180));%%Maximum 2D Seismic Length

start_A_3D_seis_monit =max_3D_seismic_A*frac_3D; %Starting area for 3D seismic monit.
start_L_2D_seis_monit =max_2D_seismic_L*frac_2D; %length for 2D seismic monit.


if strat_2_inj > Nwell_fin
    strat_2_inj_act = Nwell_fin;
else
    strat_2_inj_act = strat_2_inj;
end

strat_2_mon = sum(well_spacing(:,2))';

reg_strat_test_wells =num_strat_test_wells-(strat_2_inj+strat_2_mon);

reg_inj_well = Nwell_fin - strat_2_inj_act;%regular injection wells

num_water_production_wells = 0; %Water is considered off, Max. No. of Water Production Wells
num_water_disposal_wells = 0; %Water is off Max. No. of Water Disposal Wells

well_spacing(1,7) = ceil(ACO2plUn/well_spacing(1,1));
well_spacing(2,7) = ceil((CO2_Pressure_Front_AoR-ACO2plUn)/well_spacing(2,1));
well_spacing(3,7) = ceil(ACO2plUn/well_spacing(3,1));
well_spacing(4,7) = ceil((CO2_Pressure_Front_AoR-ACO2plUn)/well_spacing(4,1));
well_spacing(5,7) = ceil(ACO2plUn/well_spacing(5,1));
well_spacing(6,7) = ceil((CO2_Pressure_Front_AoR-ACO2plUn)/well_spacing(6,1));

well_spacing(:, 8) = max([well_spacing(:, 2), well_spacing(:, 3), well_spacing(:, 4)], [], 2);

well_spacing(:, 9) = min([max([well_spacing(:, 5), zeros(size(well_spacing, 1), 1) ], [], 2),max([well_spacing(:, 7), well_spacing(:, 8)], [], 2)],[],2);

well_spacing(:,10) = max([well_spacing(:, 2), zeros(size(well_spacing, 1), 1),well_spacing(:, 9)], [], 2);

%% Plume Flows
%CO2 Plume Area & Other Area Calcs
plume_area_other = zeros(24, pisc_closure(3));  % Preallocate the plume_area_other array

i = 1:pisc_closure(3);

%CO2 Plume
plume_area_other(1,i) = ((i >= operations(2)) .* min((ACO2plz / operations(1)) * (i - operations(2) + 1), ACO2plz)) + ((i < operations(2)) .* 0);
plume_area_other(2,i) = (i < operations(2)) .* (ACO2plz * PlumeUnArmult) + (i >= operations(2)) .* (plume_area_other(1,i) * PlumeUnArmult);
plume_area_other(3,i) = plume_area_other(2,i) .* PlumePrFAORmult;
plume_area_other(4,i) = (i < operations(2)) .* plume_area_other(2,i) + (i >= operations(2)) .* (i <= operations(3)) .* (ACO2plUn * (frac_3D + (1 - frac_3D) .* (i - operations(2)) / (operations(3) - operations(2)))) + (i > operations(3)) .*ACO2plUn;
plume_area_other(5,i) = pi*(sqrt(plume_area_other(4,i)/pi)+Lbot*tan(Ang3DSeis*pi/180)).^2;
plume_area_other(6,i) = (i < operations(2)) .* plume_area_other(2,i) + (i >= operations(2)) .* (i <= operations(3)) .* (ACO2plUn * (frac_2D + (1 - frac_2D) .* (i - operations(2)) / (operations(3) - operations(2)))) + (i > operations(3)) .*ACO2plUn;
plume_area_other(7,i) = 2*(sqrt(plume_area_other(6,i)/pi)+Lbot*tan(Ang2DSeis*pi/180));

%All Types of Strat Test Wells
plume_area_other(9,i) = (i >= strat(1)).*num_strat_test_wells + (i < strat(1)) .* 0;
plume_area_other(8, i) = plume_area_other(9, i) .* (i == 1) + (plume_area_other(9, i) - plume_area_other(9, max(i - 1, 1))) .* (i ~= 1);

%Regular Strat Test Wells
plume_area_other(11,i) = (i >= strat(1)).*reg_strat_test_wells + (i < strat(1)) .* 0;
plume_area_other(10, i) = plume_area_other(11, i) .* (i == 1) + (plume_area_other(11, i) - plume_area_other(11, max(i - 1, 1))) .* (i ~= 1);

%Strat Wells to Mon. Wells. 
plume_area_other(13,i) = (i >= strat(1)).*strat_2_mon + (i < strat(1)) .* 0;
plume_area_other(12, i) = plume_area_other(13, i) .* (i == 1) + (plume_area_other(13, i) - plume_area_other(13, max(i - 1, 1))) .* (i ~= 1);

%Injection Wells 
%Strat wells converted to inj wells
plume_area_other(14,i) = (i == strat(1)).*strat_2_inj_act + (i ~= strat(1)) .* 0;
plume_area_other(15,i) = (i == inj(1)).*strat_2_inj_act + (i ~= inj(1)) .* 0;
plume_area_other(16,i) = (i >= inj(1)).*strat_2_inj_act + (i < inj(1)) .* 0;

%Regular Injection wells
plume_area_other(18,i) = (i >= inj(1)).*reg_inj_well + (i < inj(1)) .* 0;
plume_area_other(17, i) = plume_area_other(18, i) .* (i == 1) + (plume_area_other(18, i) - plume_area_other(18, max(i - 1, 1))) .* (i ~= 1);

plume_area_other(19,i) = plume_area_other(17, i) + plume_area_other(15, i);
plume_area_other(20,i) = plume_area_other(18, i) + plume_area_other(16, i);

plume_area_other(22,i) = (i >= monitoring(1)).*num_water_production_wells+ (i < monitoring(1)) .* 0;
plume_area_other(21, i) = plume_area_other(22, i) .* (i == 1) + (plume_area_other(22, i) - plume_area_other(22, max(i - 1, 1))) .* (i ~= 1);

plume_area_other(24,i) = (i >= monitoring(1)).*num_water_disposal_wells + (i < monitoring(1)) .* 0;
plume_area_other(23, i) = plume_area_other(24, i) .* (i == 1) + (plume_area_other(24, i) - plume_area_other(24, max(i - 1, 1))) .* (i ~= 1);

%Monitoring Wells Schedules 
monitoring_wells_reservoir = zeros(13, pisc_closure(3));

monitoring_wells_reservoir(3,i) = (i >= monitoring(1)).*ceil(plume_area_other(2,i).*(well_spacing(1,10)/ACO2plUn)) + (i < monitoring(1)) .* 0;
monitoring_wells_reservoir(4,i) = (i == monitoring(1)).*well_spacing(1,2) + (i ~= monitoring(1)).*0;
monitoring_wells_reservoir(6,i) = (well_spacing(1,10) == 0) * 0 + (well_spacing(1,10) ~= 0) .* (i < monitoring(1)) .* 0 + (well_spacing(1,10) ~= 0) .* (i == monitoring(1)) .* max(well_spacing(1,6), monitoring_wells_reservoir(3,i)) + (well_spacing(1,10) ~= 0) * (i > monitoring(1)) .* max(monitoring_wells_reservoir(3,i), monitoring_wells_reservoir(6,max(i-1,1)));
monitoring_wells_reservoir(5,i) = (i == 1) .* monitoring_wells_reservoir(6,i) + (i ~= 1) .* monitoring_wells_reservoir(6,i) - monitoring_wells_reservoir(6,max(i-1,1)) - monitoring_wells_reservoir(4,i);

monitoring_wells_reservoir(1,i) = ((monitoring_wells_reservoir(6,i) > 0) .* plume_area_other(2,i)./max(1,monitoring_wells_reservoir(6,i))) + (monitoring_wells_reservoir(6,i) <= 0) * 0;

monitoring_wells_reservoir(7,i) = (i >= monitoring(1)).*ceil((plume_area_other(3,i)-plume_area_other(2,i)).*(well_spacing(2,10)/(CO2_Pressure_Front_AoR-ACO2plUn))) + (i < monitoring(1)) .* 0;
monitoring_wells_reservoir(8,i) = (i == monitoring(1)).*well_spacing(2,2) + (i ~= monitoring(1)).*0;
monitoring_wells_reservoir(10,i) = (well_spacing(2,10) == 0) * 0 + (well_spacing(2,10) ~= 0) .* (i < monitoring(1)) .* 0 + (well_spacing(2,10) ~= 0) .* (i == monitoring(1)) .* max(well_spacing(2,6), monitoring_wells_reservoir(7,i)) + (well_spacing(2,10) ~= 0) * (i > monitoring(1)) .* max(monitoring_wells_reservoir(7,i), monitoring_wells_reservoir(10,max(i-1,1)));
monitoring_wells_reservoir(9,i) = (i == 1) .* monitoring_wells_reservoir(10,i) + (i ~= 1) .* monitoring_wells_reservoir(10,i) - monitoring_wells_reservoir(10,max(i-1,1)) - monitoring_wells_reservoir(8,i);

monitoring_wells_reservoir(2,i) = ((monitoring_wells_reservoir(10,i) > 0) .* (plume_area_other(3,i)-plume_area_other(2,i))./max(1,monitoring_wells_reservoir(10,i))) + (monitoring_wells_reservoir(10,i) <= 0) * 0;

monitoring_wells_reservoir(11,i) = monitoring_wells_reservoir(4,i)+monitoring_wells_reservoir(8,i);
monitoring_wells_reservoir(12,i) = monitoring_wells_reservoir(5,i)+monitoring_wells_reservoir(9,i);
monitoring_wells_reservoir(13,i) = monitoring_wells_reservoir(6,i)+monitoring_wells_reservoir(10,i);

%Monitoring Wells above Seal
monitoring_wells_above = zeros(13, pisc_closure(3));

monitoring_wells_above(3,i) = (i >= monitoring(1)).*ceil(plume_area_other(2,i).*(well_spacing(3,10)/ACO2plUn)) + (i < monitoring(1)) .* 0;
monitoring_wells_above(4,i) = (i == monitoring(1)).*well_spacing(3,2) + (i ~= monitoring(1)).*0;
monitoring_wells_above(6,i) = (well_spacing(3,10) == 0) * 0 + (well_spacing(3,10) ~= 0) .* (i < monitoring(1)) .* 0 + (well_spacing(3,10) ~= 0) .* (i == monitoring(1)) .* max(well_spacing(3,6), monitoring_wells_above(3,i)) + (well_spacing(3,10) ~= 0) * (i > monitoring(1)) .* max(monitoring_wells_above(3,i), monitoring_wells_above(6,max(i-1,1)));
monitoring_wells_above(5,i) = (i == 1) .* monitoring_wells_above(6,i) + (i ~= 1) .* monitoring_wells_above(6,i) - monitoring_wells_above(6,max(i-1,1)) - monitoring_wells_above(4,i);

monitoring_wells_above(1,i) = ((monitoring_wells_above(6,i) > 0) .* plume_area_other(2,i)./max(1,monitoring_wells_above(6,i))) + (monitoring_wells_above(6,i) <= 0) * 0;

monitoring_wells_above(7,i) = (i >= monitoring(1)).*ceil((plume_area_other(3,i)-plume_area_other(2,i)).*(well_spacing(4,10)/(CO2_Pressure_Front_AoR-ACO2plUn))) + (i < monitoring(1)) .* 0;
monitoring_wells_above(8,i) = (i == monitoring(1)).*well_spacing(4,2) + (i ~= monitoring(1)).*0;
monitoring_wells_above(10,i) = (well_spacing(4,10) == 0) * 0 + (well_spacing(4,10) ~= 0) .* (i < monitoring(1)) .* 0 + (well_spacing(4,10) ~= 0) .* (i == monitoring(1)) .* max(well_spacing(4,6), monitoring_wells_above(7,i)) + (well_spacing(4,10) ~= 0) * (i > monitoring(1)) .* max(monitoring_wells_above(7,i), monitoring_wells_above(10,max(i-1,1)));
monitoring_wells_above(9,i) = (i == 1) .* monitoring_wells_above(10,i) + (i ~= 1) .* monitoring_wells_above(10,i) - monitoring_wells_above(10,max(i-1,1)) - monitoring_wells_above(8,i);

monitoring_wells_above(2,i) = ((monitoring_wells_above(10,i) > 0) .* (plume_area_other(3,i)-plume_area_other(2,i))./max(1,monitoring_wells_above(10,i))) + (monitoring_wells_above(10,i) <= 0) * 0;

monitoring_wells_above(11,i) = monitoring_wells_above(4,i)+monitoring_wells_above(8,i);
monitoring_wells_above(12,i) = monitoring_wells_above(5,i)+monitoring_wells_above(9,i);
monitoring_wells_above(13,i) = monitoring_wells_above(6,i)+monitoring_wells_above(10,i);

%Monitoring Wells Dual
monitoring_wells_dual = zeros(13, pisc_closure(3));

monitoring_wells_dual(3,i) = (i >= monitoring(1)).*ceil(plume_area_other(2,i).*(well_spacing(5,10)/ACO2plUn)) + (i < monitoring(1)) .* 0;
monitoring_wells_dual(4,i) = (i == monitoring(1)).*well_spacing(5,2) + (i ~= monitoring(1)).*0;
monitoring_wells_dual(6,i) = (well_spacing(5,10) == 0) * 0 + (well_spacing(5,10) ~= 0) .* (i < monitoring(1)) .* 0 + (well_spacing(5,10) ~= 0) .* (i == monitoring(1)) .* max(well_spacing(5,6), monitoring_wells_dual(3,i)) + (well_spacing(5,10) ~= 0) * (i > monitoring(1)) .* max(monitoring_wells_dual(3,i), monitoring_wells_dual(6,max(i-1,1)));
monitoring_wells_dual(5,i) = (i == 1) .* monitoring_wells_dual(6,i) + (i ~= 1) .* monitoring_wells_dual(6,i) - monitoring_wells_dual(6,max(i-1,1)) - monitoring_wells_dual(4,i);

monitoring_wells_dual(1,i) = ((monitoring_wells_dual(6,i) > 0) .* plume_area_other(2,i)./max(1,monitoring_wells_dual(6,i))) + (monitoring_wells_dual(6,i) <= 0) * 0;

monitoring_wells_dual(7,i) = (i >= monitoring(1)).*ceil((plume_area_other(3,i)-plume_area_other(2,i)).*(well_spacing(6,10)/(CO2_Pressure_Front_AoR-ACO2plUn))) + (i < monitoring(1)) .* 0;
monitoring_wells_dual(8,i) = (i == monitoring(1)).*well_spacing(6,2) + (i ~= monitoring(1)).*0;
monitoring_wells_dual(10,i) = (well_spacing(6,10) == 0) * 0 + (well_spacing(6,10) ~= 0) .* (i < monitoring(1)) .* 0 + (well_spacing(6,10) ~= 0) .* (i == monitoring(1)) .* max(well_spacing(6,6), monitoring_wells_dual(7,i)) + (well_spacing(6,10) ~= 0) * (i > monitoring(1)) .* max(monitoring_wells_dual(7,i), monitoring_wells_dual(10,max(i-1,1)));
monitoring_wells_dual(9,i) = (i == 1) .* monitoring_wells_dual(10,i) + (i ~= 1) .* monitoring_wells_dual(10,i) - monitoring_wells_dual(10,max(i-1,1)) - monitoring_wells_dual(8,i);

monitoring_wells_dual(2,i) = ((monitoring_wells_dual(10,i) > 0) .* (plume_area_other(3,i)-plume_area_other(2,i))./max(1,monitoring_wells_dual(10,i))) + (monitoring_wells_dual(10,i) <= 0) * 0;

monitoring_wells_dual(11,i) = monitoring_wells_dual(4,i)+monitoring_wells_dual(8,i);
monitoring_wells_dual(12,i) = monitoring_wells_dual(5,i)+monitoring_wells_dual(9,i);
monitoring_wells_dual(13,i) = monitoring_wells_dual(6,i)+monitoring_wells_dual(10,i);

%Monitoring Wells Groundwater
monitoring_ground_water = zeros(2, pisc_closure(3));
monitoring_ground_water(2,i) = (i >= monitoring(1)) .* well_spacing(7,1) .* plume_area_other(20,i) + (i < monitoring(1)) .* 0;
monitoring_ground_water(1,i) = (i == 1) .* monitoring_ground_water(2,i) + (i ~= 1) .* monitoring_ground_water(2,i) - monitoring_ground_water(2,max(i-1,1));

%Monitoring Wells Vadose Zone
monitoring_vadose= zeros(2, pisc_closure(3));
monitoring_vadose(2,i) = (i >= monitoring(1)) .* well_spacing(8,1) .* plume_area_other(20,i) + (i < monitoring(1)) .* 0;
monitoring_vadose(1,i) = (i == 1) .* monitoring_vadose(2,i) + (i ~= 1) .* monitoring_vadose(2,i) - monitoring_vadose(2,max(i-1,1));

end


