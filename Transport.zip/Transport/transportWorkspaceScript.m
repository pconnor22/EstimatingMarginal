clear
clc

%Years of operation 
base_year = 2011;
start_year = 2022;
op_years = 30;
duration_of_construction = 6;


%Contingency factor for remidiation
contingency = 0.15;

%pump costs
fixed_pump_cost = 70000; %2005 $
variable_pump_cost = 1110; % 2005$/kW

input_pressure = 15.269818; %MPa
output_pressure = 8.37506132; %MPa
dPressure = input_pressure - output_pressure;
pumpEfficency = 0.75;
temp = (53 - 32) * 5.0/9.0 + 273.15;
AveragePressure = (input_pressure + output_pressure)/2;

convert2005to2011 = 898.5/752.5;

electricityCost = 68.20; %2011$/MWhr from EIA 2022 industrial sources

O_M_percent_pipeline = 0.0250;

O_M_percent_equipment = 0.04;

brMat = [0.05, 0.4, 0.55];
brLabor = [0.05, 0.4, 0.55];
brROW = [.55,.3,.15];
brMisc = [.3,.35,.35];
brSurge = [0,.3,.7];
brControl = [0,.3,.7];
brPump = [0,.4,.6];

save("/Users/patrickconnor/Documents/MATLAB/Graduate School/Research/CCS Model V3/Transport_Data")


